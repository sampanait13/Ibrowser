package com.lifedrop.browser

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.CookieManager
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.lifedrop.browser.databinding.ActivityMainBinding
import java.net.URLEncoder

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Marcheaza ca utilizatorul a initiat manual navigarea (URL tastat / reload / back).
    // Se reseteaza dupa prima navigare consumata.
    private var userInitiatedLoad = false

    private var redirectBlockingEnabled = true
    private var blockedRedirectUrl: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        configureWebView()
        setupUi()

        val initialUrl = intent?.dataString ?: "https://duckduckgo.com"
        loadUrlAsUser(initialUrl)
    }

    private fun loadUrlAsUser(url: String) {
        userInitiatedLoad = true
        binding.webView.loadUrl(url)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun configureWebView() = with(binding.webView) {
        settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = true
            displayZoomControls = false
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString = userAgentString.replace(Regex("\\swv\\)"), ")")
        }

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

        webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val url = request.url.toString()
                val isMainFrame = request.isForMainFrame
                val isRedirect = request.isRedirect
                val hasGesture = request.hasGesture()

                if (!isMainFrame) return false

                if (!url.startsWith("http://") && !url.startsWith("https://")) {
                    return try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        true
                    } catch (e: Exception) {
                        true
                    }
                }

                if (!redirectBlockingEnabled) return false

                // MOD STRICT — doar pagina accesata, nimic altceva
                //  - URL tastat in bara / reload / back -> permis o data
                //  - Redirect HTTP 30x -> BLOCAT (chiar daca a venit dintr-un click)
                //  - JS navigheaza singur (fara gesture) -> BLOCAT
                //  - Click direct pe link -> permis

                if (userInitiatedLoad && !isRedirect) {
                    userInitiatedLoad = false
                    return false
                }

                if (isRedirect || !hasGesture) {
                    blockedRedirectUrl = url
                    runOnUiThread {
                        binding.blockedBar.visibility = View.VISIBLE
                        binding.blockedUrlText.text = getString(R.string.blocked_redirect, url)
                    }
                    return true
                }

                return false
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (!binding.urlBar.hasFocus()) {
                    binding.urlBar.setText(url ?: "")
                }
                binding.progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                binding.progressBar.visibility = View.GONE
            }

            override fun onReceivedSslError(
                view: WebView?,
                handler: SslErrorHandler?,
                error: SslError?
            ) {
                handler?.proceed()
            }
        }

        webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                binding.progressBar.progress = newProgress
            }
        }
    }

    private fun setupUi() {
        binding.urlBar.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                actionId == EditorInfo.IME_ACTION_DONE ||
                actionId == EditorInfo.IME_ACTION_SEARCH
            ) {
                val input = v.text.toString().trim()
                if (input.isNotEmpty()) {
                    loadUrlAsUser(resolveInput(input))
                    v.clearFocus()
                }
                true
            } else false
        }

        binding.backButton.setOnClickListener {
            if (binding.webView.canGoBack()) {
                userInitiatedLoad = true
                binding.webView.goBack()
            }
        }
        binding.forwardButton.setOnClickListener {
            if (binding.webView.canGoForward()) {
                userInitiatedLoad = true
                binding.webView.goForward()
            }
        }
        binding.reloadButton.setOnClickListener {
            userInitiatedLoad = true
            binding.webView.reload()
        }

        binding.allowRedirectButton.setOnClickListener {
            blockedRedirectUrl?.let { url ->
                binding.blockedBar.visibility = View.GONE
                loadUrlAsUser(url)
                blockedRedirectUrl = null
            }
        }
        binding.dismissBlockedButton.setOnClickListener {
            binding.blockedBar.visibility = View.GONE
            blockedRedirectUrl = null
        }
        binding.toggleBlockButton.setOnCheckedChangeListener { _, isChecked ->
            redirectBlockingEnabled = isChecked
            Toast.makeText(
                this,
                if (isChecked) "Blocare strictă: PORNITĂ" else "Blocare: OPRITĂ",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun resolveInput(input: String): String {
        return when {
            input.startsWith("http://") || input.startsWith("https://") -> input
            input.contains(".") && !input.contains(" ") -> "https://$input"
            else -> "https://duckduckgo.com/?q=${URLEncoder.encode(input, "UTF-8")}"
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (binding.blockedBar.visibility == View.VISIBLE) {
            binding.blockedBar.visibility = View.GONE
            blockedRedirectUrl = null
            return
        }
        if (binding.webView.canGoBack()) {
            userInitiatedLoad = true
            binding.webView.goBack()
        } else {
            @Suppress("DEPRECATION")
            super.onBackPressed()
        }
    }
}
