# LifeBrowser

Browser Android minimalist, fără filtre de conținut, cu blocare a redirect-urilor automate.

## Ce face

- WebView fără restricții (JavaScript, cookies, third-party cookies, mixed content, SSL invalide — toate permise)
- **Blochează redirect-urile automate** (HTTP 30x + JavaScript `window.location` fără click) și îți arată o bară galbenă cu URL-ul blocat — poți alege să permiți acel redirect specific
- Switch global pentru a opri/porni blocarea
- User-agent curățat de marker-ul "wv" (multe site-uri detectează WebView-urile și se comportă diferit)
- Search bar care detectează automat dacă ai introdus URL sau text de căutat
- Popup-urile (`window.open`) sunt dezactivate — sunt vectorul principal pentru ferestrele de redirect/ad

## Cum construiești APK-ul

### Varianta A — Android Studio (cea mai simplă, local)

1. Descarcă și instalează [Android Studio](https://developer.android.com/studio)
2. La prima rulare, lasă-l să descarce SDK-ul (~5 GB)
3. `File → Open` → selectează folderul `LifeBrowser`
4. Așteaptă să termine "Gradle sync" (5-10 minute prima dată)
5. `Build → Build Bundle(s) / APK(s) → Build APK(s)`
6. APK-ul va fi în `app/build/outputs/apk/debug/app-debug.apk`
7. Copiază-l pe telefon și instalează (trebuie să activezi "Install from unknown sources")

### Varianta B — GitHub Actions (build în cloud, fără nimic instalat)

1. Creează un repo nou pe GitHub
2. Urcă tot conținutul folderului `LifeBrowser` în repo
3. Mergi la tab-ul **Actions** din repo — workflow-ul `Build APK` va porni automat
4. Când termină (3-5 minute), click pe run-ul respectiv → descarcă artifact-ul `LifeBrowser-debug-apk`
5. Dezarhivează → ai APK-ul

### Varianta C — Linie de comandă (dacă ai deja SDK)

```bash
cd LifeBrowser
gradle wrapper --gradle-version 8.5
./gradlew assembleDebug
```

APK-ul iese în `app/build/outputs/apk/debug/app-debug.apk`.

## Personalizare rapidă

- **URL de pornire**: în `MainActivity.kt`, caută `"https://duckduckgo.com"` și schimbă-l
- **Numele aplicației**: în `app/src/main/res/values/strings.xml`, modifică `app_name`
- **Fereastra de gesture**: în `MainActivity.kt`, `USER_GESTURE_WINDOW_MS` — cât timp după un touch consideri navigarea ca fiind voită de utilizator (default 1500ms)
- **Package name**: dacă vrei alt ID decât `com.lifedrop.browser`, schimbă-l în `app/build.gradle` (`applicationId` + `namespace`) și redenumește folderul `java/com/lifedrop/browser/`

## Limitări cunoscute

- Blocarea redirect-urilor se bazează pe `hasGesture()` + timestamp-ul ultimului touch. E robust pentru majoritatea redirect-urilor (HTTP 30x, `window.location`, meta-refresh), dar un site poate teoretic să declanșeze un redirect imediat după ce ai dat click pe un link legitim din pagină — în acea fereastră de 1.5s, redirect-ul va fi considerat "voit". Reduce `USER_GESTURE_WINDOW_MS` la 500-800ms dacă vrei să fii mai strict (cu riscul de a bloca și navigări legitime).
- APK-ul este semnat cu debug key — funcționează perfect pentru uz personal, dar nu poate fi publicat în Play Store fără re-semnare cu o cheie de release.
